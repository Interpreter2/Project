package com.bitsbids.bitsbidsbackend.working.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MessageService {

    private final MessageRepository messageRepository;

    @Autowired
    public MessageService(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    public List<Message> getMessagesBetweenUsers(Long senderId, Long receiverId, boolean bidFrozen) {
        return (List<Message>) messageRepository.findBySenderIdAndReceiverIdAndBidFrozenOrderByTimestampAsc(senderId, receiverId, bidFrozen);
    }

    public Message sendMessage(Long senderId, Long receiverId, String content, boolean bidFrozen) {
        Message message = new Message();
        message.setSenderId(senderId);
        message.setReceiverId(receiverId);
        message.setContent(content);
        message.setTimestamp(LocalDateTime.now());
        message.setBidFrozen(bidFrozen);

        return messageRepository.save(message);
    }
}

