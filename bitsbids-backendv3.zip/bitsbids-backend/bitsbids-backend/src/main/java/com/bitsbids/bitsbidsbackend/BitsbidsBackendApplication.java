package com.bitsbids.bitsbidsbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitsbidsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitsbidsBackendApplication.class, args);
	}

}
