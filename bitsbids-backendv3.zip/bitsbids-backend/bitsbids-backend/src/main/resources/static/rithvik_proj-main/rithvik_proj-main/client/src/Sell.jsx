import React, {useState} from 'react'
import Header from './components/Header';

const Sell = () => {
    const [file, setFile] = useState();
    const [title, setTitle] = useState();
    const [description, setDescription] = useState();
    const [price, setPrice] = useState();
    
    const handleChange = (e) => {
        console.log(e.target.files);
        setFile(URL.createObjectURL(e.target.files[0]));
    }

    return (
        <>
            <Header />
           
            <div className='flex flex-col space-y-10 items-center py-10'>
                <div>
                    <div>Title:</div>
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className='border-2 w-96 border-black rounded-md h-10'/>
                </div>

                <div>
                    <div>Description:</div>
                    <textarea type="text" value={description} onChange={(e) => setDescription(e.target.value)} className='border-2 w-96 border-black rounded-md h-40'/>
                </div>

                <div>
                    <div>Price:</div>
                <input type="text" value={price} onChange={(e) => setPrice(e.target.value)} className='border-2 w-96 border-black rounded-md h-10'/>
                </div>

                <input type="file" onChange={handleChange} />
            <img src={file} className='w-80'/>

            <div className='bg-blue-500 w-64 h-10 rounded-md flex justify-center items-center'>
                <div>Submit</div>
            </div>
            </div>

           



        </>
    )
}

export default Sell