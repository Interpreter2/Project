import React from 'react'
import Header from './components/Header'
import computer from './assets/imgs/computer.jpeg'

const AuctionPage = () => {
    return (
        <>
            <Header />
            <div className='flex mt-20'>
                <div className='flex-1'>
                    <img src={computer} className='w-[30rem] mx-auto' />
                </div>
                <div className='flex-1'>
                    <div className='text-3xl font-bold'>MacBook Pro</div>
                    <div className='opacity-50'>Add Description</div>
                    <div className='flex items-end space-x-20'>
                        <div>
                            <div>Time Left: 3m 5s</div>
                            <div className='mt-10'>Asking Price:</div>
                            <div><strong>400</strong> Bitscoin</div>
                        </div>
                        <div className='flex flex-col space-y-2'>
                            <button className='bg-green-500 px-10 py-2 rounded-lg'>Chat with seller</button>
                            <button className='bg-blue-500 px-10 py-2 rounded-lg'>Bid</button>
                        </div>
                    </div>


                </div>
            </div>
        </>
    )
}

export default AuctionPage