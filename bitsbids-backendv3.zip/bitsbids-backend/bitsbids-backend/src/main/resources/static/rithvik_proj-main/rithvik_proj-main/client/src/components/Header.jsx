import React, { useState } from 'react'

const Header = () => {
  const [input, setInput] = useState()

  return (
    <>
      <div className='flex items-center  bg-blue-500'>
        <div className='bg-green-500 h-20 w-40 flex justify-center items-center'>
          <a href='/' className='text-2xl'>Bids</a>
        </div>
        <input type="text" value={input} onChange={(e) => setInput(e.target.value)} className='border-2 border-black w-[35rem] h-11 mx-auto px-5 rounded-lg'  />
      </div>
      <div className='flex justify-evenly mt-5'>
        <a href='/'>Home</a>
        <button>Saved</button>
        <button>Electronics</button>
        <button>Motors</button>
        <button>Fashion</button>
        <button>Collectible and Art</button>
        <button>Sports</button>
        <button>Health & Beauty</button>
        <button>Industrial equipment</button>
        <button>Home & Garden</button>
        <button>Deals</button>
        <a href='/sell'>Sell</a>
      </div>
    </>
  )
}

export default Header