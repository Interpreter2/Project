import React, { useState } from 'react'
import Header from './components/Header'
import home from './assets/imgs/home.jpg'
import computer from './assets/imgs/computer.jpeg'
import makeup from './assets/imgs/makeup.jpeg'
import phone from './assets/imgs/phone.jpg'
import shoes from './assets/imgs/shoes.jpg'
import toy from './assets/imgs/toy.jpeg'
import shipping from './assets/imgs/shipping.jpg'
import cart from './assets/imgs/cart.png'
import craigslist from './assets/imgs/craigslist.jpg'

const App = () => {
  return (
    <>
      <Header />

      <div className='mt-10 mb-5 mx-10'>Our Services</div>

      <div className='flex justify-evenly mx-10 items-baseline'>

        <ItemCard img={shipping} text='Packaging and Shipping' />

        <ItemCard img={cart} text='Shopping Assistance' />

        <ItemCard img={craigslist} text='Listing Services' />
      </div>



      <div className='mt-10 mb-5 mx-10'>Popular Destinations</div>

      <div className='flex justify-evenly mx-10 items-baseline'>

        <ItemCard img={phone} text='Cellphones & Accessories' />

        <ItemCard img={shoes} text='Shoes' />

        <ItemCard img={computer} text='Cellphones & Accessories' />

        <ItemCard img={toy} text='Toys' />

        <ItemCard img={makeup} text='Makeup' />

        <ItemCard img={home} text='Home' />
      </div>

    </>
  )
}

export default App

const ItemCard = ({ img, text }) => {
  return (
    <div className='flex flex-col justify-center items-center'>
      <img src={img} alt="" className='w-40 object-contain h-40' />
      <div className=''>{text}</div>
    </div>
  )
}