package com.bitsbids.bitsbidsbackend.working.product;

import com.bitsbids.bitsbidsbackend.working.UserProfile;
import jakarta.persistence.*;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private String category;
    private double price;

    // Add any other necessary fields...

    @ManyToOne
    @JoinColumn(name = "seller_id")
    private UserProfile seller;

    // Constructors, getters, setters...
}