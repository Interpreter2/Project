package com.bitsbids.bitsbidsbackend.working;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String phone;
    private String hostel;
    private String profilePicturePath; // Add this for profile pictures
    private boolean pictureVisible;
    private boolean bidFrozen;

    // Constructors, getters, setters...
}