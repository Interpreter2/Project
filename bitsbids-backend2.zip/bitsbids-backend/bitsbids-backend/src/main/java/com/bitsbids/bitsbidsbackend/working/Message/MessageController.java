package com.bitsbids.bitsbidsbackend.working.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/messages")
public class MessageController {

    private final MessageService messageService;

    @Autowired
    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    @GetMapping("/get")
    public List<Message> getMessages(@RequestParam Long senderId, @RequestParam Long receiverId, @RequestParam boolean bidFrozen) {
        return messageService.getMessagesBetweenUsers(senderId, receiverId, bidFrozen);
    }

    @PostMapping("/send")
    public Message sendMessage(@RequestParam Long senderId, @RequestParam Long receiverId, @RequestParam String content, @RequestParam boolean bidFrozen) {
        return messageService.sendMessage(senderId, receiverId, content, bidFrozen);
    }
}
