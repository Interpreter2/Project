package com.bitsbids.bitsbidsbackend.working.Message;

import org.hibernate.mapping.List;
import org.springframework.data.jpa.repository.JpaRepository;


public interface MessageRepository extends JpaRepository<Message, Long> {
    List findBySenderIdAndReceiverIdAndBidFrozenOrderByTimestampAsc(Long senderId, Long receiverId, boolean bidFrozen);
}

